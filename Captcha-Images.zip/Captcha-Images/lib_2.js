var message = 'welcome to AJ!';
exports.welcomeNote = function () {

    console.log(message);

};