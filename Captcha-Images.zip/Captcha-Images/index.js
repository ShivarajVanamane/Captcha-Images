const add = require('./common_lib/lib_1');
console.log(add(10, 10));